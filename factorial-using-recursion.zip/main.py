f=1
def fact(n):
    if (n==0) or (n==1):
        return 1
    else:
        return (n*fact(n-1))
j=fact(int(input("enther the elemnt u want to find the fact")))    
print(j)